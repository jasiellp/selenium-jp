package com.tangerino.api.util;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class RestClientUtil 
{
	 
	public static String post(String url , RequestBody body,ArrayList<String> listHeader) throws IOException 
	{
		OkHttpClient client = new OkHttpClient();
 
		Request.Builder builder = new Request.Builder().url(url);
		
		if(listHeader != null)
		{
			for(String header : listHeader)
			{
				String[] vectHeader =  header.split(";");
				
				if(vectHeader.length>=1)
				{
					builder.addHeader(vectHeader[0],vectHeader[1]);
				}
			}
		}
		
		Request request = builder.post(body).build();
  
		Response response = client.newCall(request).execute();
		
		return response.body().string();

	}
}
