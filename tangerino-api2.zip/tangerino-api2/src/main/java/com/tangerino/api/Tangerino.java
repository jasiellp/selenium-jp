package com.tangerino.api;

import java.awt.AWTException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Tangerino {

	public static void main(String[] args) throws IOException, InterruptedException, AWTException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Jasiel.SantAna\\eclipse-workspace\\tangerino-api2\\webdrivers\\chrome\\windows\\85.0.4183.87\\chromedriver.exe");
	     
		ChromeOptions chromeOptions = new ChromeOptions();
	  //chromeOptions.addArguments("--headless");
	       
		WebDriver driver = new ChromeDriver(chromeOptions);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	 	driver.get("https://google.com");
		
		Thread.sleep(200);
		  
		System.exit(8);
	// registraPonto
	} 
}
